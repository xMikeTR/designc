# Research behind the features

What a senior or principal engineer checks when designing a system, and what is specific to agentic systems, mapped to where it shows up in this package. Sources were reviewed in September 2026.

## General system design

| Practice | Source | Where it lives |
| --- | --- | --- |
| Quality attributes ("-ilities") drive architecture; they conflict, so each design is a set of trade-offs | [Microsoft Engineering Playbook: non-functional requirements capture](https://microsoft.github.io/code-with-engineering-playbook/design/design-patterns/non-functional-requirements-capture-guide/); ISO 25010 families | Quality properties in `vocabulary.js`; per-element questions in the review |
| Reviews test the architecture against scenarios and business goals, not just diagrams | Architecture review practice (e.g. Mozilla's architecture review process; ATAM) | Review sections for decisions, threats and capacity |
| Decisions are documented and motivated | Design review checklists | "Decisions to record" in the review; designc's decision files |
| Disaster recovery: RTO, RPO, tested restores | NFR capture guide (operational requirements) | `d.rto`, `d.rpo`, `d.backup`; store questions |
| Threats at trust boundaries: STRIDE | Microsoft threat modelling | STRIDE table per crossing (uses designc's `d.zone`) |
| Back-of-the-envelope capacity: requests, peak factor, storage growth | Common system design practice | `review.capacity()` |

## Agentic systems

| Practice | Source | Where it lives |
| --- | --- | --- |
| Ten agentic risks: goal hijack, tool misuse, identity abuse, supply chain, code execution, memory poisoning, inter-agent comms, cascading failures, human-agent trust, rogue agents | [OWASP Top 10 for Agentic Applications 2026](https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/) (OWASP GenAI Security Project) | OWASP table per agent in the review; rules AG001 to AG010 name the risk they come from |
| Private data + untrusted content + external communication in one agent lets injected instructions exfiltrate data; guardrail filters are not a fix | [Simon Willison, The lethal trifecta](https://simonwillison.net/2025/Jun/16/the-lethal-trifecta/) | `d.agent.untrustedInput/privateData/externalComms`; AG001 (with graph inference); RAG template keeps two legs, never three |
| Five workflow patterns (prompt chaining, routing, parallelization, orchestrator-workers, evaluator-optimizer); prefer the simplest; add autonomy only where steps can't be predicted | Anthropic, "Building effective agents" (2024) | Pattern table in the review; orchestrator-workers and evaluator-optimizer templates |
| Put the write path behind a gate; set stopping conditions (iteration caps, time, token budget) before tuning prompts | Agentic workflow guidance (e.g. Orca Security's agentic workflows guide, 2026) | `d.approval`, `d.tool.effect`, AG002; `d.agent.maxSteps`, `d.agent.budget`, AG003 |
| Excessive agency | OWASP LLM06 | `d.agent.autonomy`, AG002 |
| Model calls through one gateway for budgets, keys, routing and tracing | Governed platform practice (designc's architecture) | AG004; templates route through an AI gateway |

## Deliberate limits

The rules are structural: they read what the design declares. They cannot see a prompt, a tool description or model behaviour, so they complement red-teaming and evals rather than replacing them. OWASP lists and adapter APIs move; re-check the sources when the next edition lands and update `vocabulary.js`.
