# designc-canvas

Draw systems the way you would on a whiteboard, and get a principal engineer's review as you go. A self-contained functionality block for [designc](../designc-desktop): no dependencies, vanilla JavaScript, tested.

- **Drawing canvas.** Drag stencils in, drag between boxes to connect, drag to move, edit in the inspector, Delete to remove, Ctrl+Z to undo. Every action is a surgical edit to the Structurizr DSL that keeps your formatting and comments. The DSL stays the single source of truth; positions live separately in `layout.json`.
- **Stencils for system design and agentic systems.** C4 (person, system, external system, service, web app, worker), data (database, cache, blob storage, queue, search), edge (API gateway, identity provider, scheduler) and agentic (agent, orchestrator, LLM, AI gateway, tool, MCP server, vector memory, policy engine, human approval, evaluator, trace store). Each draws with its own shape.
- **Design vocabulary.** New `d.*` properties for quality attributes (owner, latency, throughput, RTO/RPO, data classification, PII, scaling, backup) and agent design (autonomy, step and budget caps, the lethal-trifecta legs, code execution and sandboxing, identity, memory, tracing, evals, tool side effects, approvals, protocol).
- **Agentic lint rules AG001 to AG010**, each mapped to the OWASP Top 10 for Agentic Applications 2026 or the lethal trifecta, and demand-driven like designc's own rules.
- **Design review generator.** Open findings, decisions to record, quality-attribute questions per element, STRIDE per trust-boundary crossing, the ten OWASP agentic risks per agent, and a capacity and agent-cost estimate. Exported as Markdown.
- **Reference architectures.** Governed agent with tools, agentic RAG, orchestrator-workers, evaluator-optimizer, event-driven with outbox, and the design-to-code factory. Every template lints clean, so each one shows what "good" looks like.

![Canvas](docs/canvas.png)

![Design review](docs/review.png)

## Try it

Open `demo/index.html` in a browser (or Electron). The DSL on the left and the canvas on the right stay in sync both ways.

```
npm test        # 25 tests: DSL edits, rules, templates, review
```

## Use it in designc

See [AGENTS.md](AGENTS.md): a two-function patch to designc's compiler, then mount the canvas with a small host object.

## Layout

| Path | What |
| --- | --- |
| `src/dsl-edit.js` | Offset-aware DSL locator and pure text edits: add element, add relationship, set property, set field, add tag, delete, insert template |
| `src/canvas.js`, `src/canvas.css` | The canvas component (`mount(el, host)`) |
| `src/vocabulary.js` | Stencils, properties, review question banks, OWASP and pattern references |
| `src/agentic-rules.js` | AG001 to AG010 |
| `src/review.js` | Design review and capacity estimate |
| `src/templates.js` | Reference architectures |
| `src/layout.js` | Positions, auto layout, boundaries |
| `vendor/core.js` | designc's compiler with the two extension hooks, for the demo and tests |
| `integration/core-hooks.patch` | The hooks as a patch against designc's `renderer/core.js` |
| `demo/` | Standalone demo |
| `test/` | `node --test` suites |
