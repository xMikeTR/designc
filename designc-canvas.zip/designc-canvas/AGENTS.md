# AGENTS.md: designc-canvas

Context for coding agents integrating this package into designc or changing it. The rules of designc apply here too: the DSL is the source of truth, probabilistic components propose and deterministic ones decide, and every change keeps the tests green.

## Architecture in one paragraph

Every module is a UMD-style file that works as a classic browser script (it registers itself on `window.DesigncCanvas`) and as a CommonJS module in Node. `dsl-edit.js` locates statements in the DSL with character offsets and applies pure text edits, so the canvas never regenerates the file. `canvas.js` renders the model parsed by designc's `Core.parse`, turns pointer and keyboard actions into `dsl-edit` calls, and hands the new text to the host. The host owns the text and the layout; the canvas keeps no second copy of the truth. `vocabulary.js` and `agentic-rules.js` extend designc's compiler through two hooks, so the new properties validate (no DC000) and AG001 to AG010 run wherever designc lints: the problems panel, the gate, the agent panel's `get_findings`, CI.

## Integrating into designc

1. **Patch the compiler.** Apply `integration/core-hooks.patch` to `renderer/core.js`. It adds `registerProperties(specs)`, `registerRules(rules)` and `specsFor(target)` and changes nothing else. `vendor/core.js` is the patched file for reference.
2. **Copy the files.** Put `src/*.js` and `src/canvas.css` in `renderer/canvas/`. In `renderer/index.html`, after `core.js` and before `app.js`, add in this order: `vocabulary.js`, `dsl-edit.js`, `layout.js`, `templates.js`, `agentic-rules.js`, `review.js`, `canvas.js`, plus `<link rel="stylesheet" href="canvas/canvas.css">`. The CSP already allows same-origin scripts.
3. **Register before the first compile.** At the top of `app.js`'s boot, before any `recompile()`:
   ```js
   Core.registerProperties(DesigncCanvas.vocabulary.coreSpecs());
   Core.registerRules(DesigncCanvas.agenticRules.makeRules(Core));
   Core.__dcvRegistered = true;   // the canvas skips registering again
   for (const row of DesigncCanvas.vocabulary.propsList()) { PROPS.push(row); PROP.set(row[0], { key: row[0], target: row[1], values: row[2], doc: row[3] }); }
   ```
   `PROPS` and `PROP` in `app.js` drive Monaco completions and hovers, so the new properties autocomplete in the DSL editor too.
4. **Mount the canvas** as a special tab (`special:canvas`, activity bar icon "Canvas"), following the recipe for views in designc's `AGENTS.md`. Keep the read-only C4 sheet as the quick view beside the editor; the canvas is the full-width drawing surface.
   ```js
   let canvas = null, canvasLayout = null;
   async function loadCanvasLayout() { try { canvasLayout = JSON.parse(await readText('model/layout.json')); } catch { canvasLayout = null; } }
   function mountCanvas(el) {
     canvas = DesigncCanvas.canvas.mount(el, {
       core: Core,
       getText: () => A.modelText,
       setText: async (text) => {                       // canvas edits go through the model buffer, like typing
         await openFile(A.cfg.model); const m = A.buffers.get(A.cfg.model).model;
         m.pushEditOperations([], [{ range: m.getFullModelRange(), text }], () => null);   // Monaco undo keeps working
         A.modelText = text; recompile(); renderAll({ keepEditor: true });
       },
       getLayout: () => canvasLayout,
       setLayout: (l) => { canvasLayout = l; host.write('model/layout.json', JSON.stringify(l, null, 2) + '\n'); },
       check: (model) => Core.check(model, { chainHops: A.cfg.chainHops || 4 }),
       onReveal: (line) => openFile(A.cfg.model, line),
       onSelect: (sel) => { A.selected = sel && sel.kind === 'element' ? sel.id : null; },
       saveReview: async (md) => {
         const name = `reviews/${new Date().toISOString().slice(0, 10)}-design-review.md`;
         await host.write(name, md); await host.appendLedger('designc.jsonl', { kind: 'design_review', file: name, by: A.user });
       },
     });
   }
   ```
   Call `canvas.refresh()` (debounced, about 250 ms) whenever the model buffer changes by typing or on disk, and when `model/layout.json` changes. `refresh()` is a no-op when nothing changed. Unmount with `canvas.destroy()` when the folder changes. Note that `setText` leaves the buffer dirty; the user saves with Ctrl+S as with typing. If you prefer autosave, call `save(A.cfg.model)` at the end of `setText`.
5. **Registry layout.** Add `model/layout.json` and `reviews/` to the registry table in designc's README and `AGENTS.md`, and `design_review` to the ledger events table.
6. **Agent panel (optional).** Add a reader tool `get_design_review` that returns `DesigncCanvas.review.generate(Core, A.model, A.diags).markdown`, allowed for all roles. AG findings already flow through `get_findings`.
7. **Tests.** Copy `test/` into designc's repo (or keep this repo as a dependency) and run `npm test` (Node 21 or later; it passes a quoted glob that Node expands itself, so it works in Windows shells too). The core-rules test pins the sample model's findings, so it also guards the patch.

## Host contract

`DesigncCanvas.canvas.mount(el, host)` returns `{ refresh, fit, undo, redo, select(identOrName), addStencil(id, x, y, name), connect(a, b, description), insertTemplate(id), openReview(), review(), state(), destroy() }`.

| Host member | Required | Contract |
| --- | --- | --- |
| `core` | yes | designc's `Core` with the hooks. Throws a clear error if missing |
| `getText()` | yes | Current DSL text |
| `setText(text, { label })` | yes | Apply the new text. The label ("Add Agent", "Set d.tool.effect") is for undo menus or logs |
| `getLayout()` / `setLayout(layout)` | no | `{ version: 1, positions: { ident: { x, y } }, viewport }`. Without them layout is automatic |
| `check(model)` | no | Returns diagnostics. Default `Core.check(model)` |
| `onReveal(line)`, `onSelect(sel)`, `saveReview(markdown, review)` | no | Navigation, selection sync, and the review's "Save" button (hidden when absent) |

The canvas keeps its own undo history of text snapshots (Ctrl+Z on the canvas). Monaco's undo also works because `setText` goes through `pushEditOperations`.

## Invariants: do not break these

| Invariant | Where |
| --- | --- |
| The DSL is the only model. The canvas never stores elements, relationships or properties anywhere else | `canvas.js` re-parses after every edit |
| Edits are surgical: formatting, comments, ordering and unrelated lines are untouched | `dsl-edit.js`; test "comments and formatting survive edits" |
| Every edit leaves a DSL that `Core.parse` accepts with no errors | All `dsl-edit` tests assert this |
| Element order from `locate()` matches `Core.parse`, so auto ids line up | Test "locate lines up with Core.parse"; keep the locator's grammar in step with `core.js` |
| New elements go before the first top-level relationship; new relationships at the end of the model | `addElement`, `addRelationship` (Structurizr resolves identifiers in order) |
| Layout never touches the DSL | `layout.js`, `setLayout` |
| Rules are demand-driven: an undeclared property is only a finding where a rule needs it | `agentic-rules.js` |
| Every template lints clean | Test "every template lints clean" |
| Registering the vocabulary does not change designc's own findings | Test "core rules are unchanged by registration" |
| All interpolated HTML is escaped | `esc()` in `canvas.js` |

## Recipes

**Add a stencil.** Add an entry to `STENCILS` in `vocabulary.js` (`id, group, label, kind, tags, shape, glyph`, optional `tech` and `props`). If it needs a new shape, add a case to `shapeSVG` in `canvas.js` and a tag mapping to `TAG_SHAPES`, so hand-written DSL gets the same shape.

**Add a property.** Add a row to `PROPERTIES` (`key, target, kind, values, group, doc, source`). It then validates, appears in the inspector under its group, and autocompletes in designc once `propsList()` is registered.

**Add a rule.** Add an entry to `makeRules` with a `source` naming the risk or incident. Use `get` for properties, emit `unknown: true` warnings for undeclared inputs, add a test that it fires and one that it stays quiet, and check every template still lints clean.

**Add a template.** Add to `TEMPLATES` with `{p}` in every identifier and name that must be unique. Declare the practices it stands for; the template test requires it to lint clean.

**Add a review section.** Extend `generate()` and `toMarkdown()` in `review.js`. Escape table cells with `c_()`: hints contain `|`.

## Known limitations

The layout is layered left to right and does not keep people or external systems outside a system's boundary; use Tidy or drag. Relationships are straight lines. Moving a container into a different system is done in the DSL (the canvas does not reparent on drag). The locator follows designc's DSL subset, not all of Structurizr. Deployment views and dynamic views are not drawn. The rules are structural and cannot see prompts, tool descriptions or model behaviour.
